sum = (a, b) => {
    return(a+b)
  }
    x= sum(17,33)
    console.log(x);