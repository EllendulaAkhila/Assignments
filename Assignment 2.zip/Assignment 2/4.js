const login=(userName='CT',password='CT')=>
{
    console.log(`The user name :${userName}`);
    console.log(`The password is : ${password}`);
}
login();