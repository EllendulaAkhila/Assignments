function sum(a=10,b=10,...c)
{
     var result=a+b
     for( let i=0;i<c.length;i++)
     {
        result += c[i]
     }
     return result;

    }
    console.log(`Sum:${sum()}`);
