function displayMax(arg1, arg2, arg3) {
    return Math.max(arg1, arg2, arg3);
}


console.log(`The Maximum Number is :${displayMax(17, 24, 18)}`);