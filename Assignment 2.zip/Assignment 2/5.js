const vehicle = {
    vehicleid: 1987,
    brand: 'Nexon',
    model: '2019',
    varient: 'one year',
    specification: {
        firstGear: function () {
            console.log('Vehicle is in First Gear.');

        },
        secondGear: function () {
            console.log('Vehicle is in Second Gear');

        },
        maxSpeed: 60,
        changeGear: function () {
            return (this.firstGear(), this.secondGear());

        },


    },


}
console.log(`The vehicle Id is:${vehicle.vehicleid}`);
console.log(`The vehicle brand is:${vehicle.brand}`);
console.log(`The vehicle model is:${vehicle.model}`);
console.log(`The vehicle varient is:${vehicle.varient}`);
vehicle.specification.changeGear();
console.log(vehicle.specification.maxSpeed);
